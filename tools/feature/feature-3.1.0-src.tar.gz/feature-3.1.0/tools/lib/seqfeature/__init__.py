#! /usr/bin/env python
# $Id: __init__.py,v 1.1 2004/09/19 01:09:40 mliang Exp $
# Copyright (c) 2004 by Mike Liang. All rights reserved.

