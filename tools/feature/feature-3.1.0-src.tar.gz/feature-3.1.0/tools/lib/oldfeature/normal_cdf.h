/* $Id: normal_cdf.h,v 1.1 2001/12/04 19:23:25 mliang Exp $ */
/* Copyright (c) 2001 Mike Liang.  All rights reserved. */

#ifndef NORMAL_CDF_H
#define NORMAL_CDF_H

extern double normal_cdf(double z);

#endif
