
#
# FEATURE Extensions
#

# Filename Extensions
SITEFILE_EXT=".site"
PDB_EXT=".FULL"
DSSP_EXT=".DSSP"
STATFILE_EXT=".sitedataaf"
SCOREFILE_EXT=".score"
HITSFILE_EXT=".hits"
