#! /usr/bin/env python
# $Id: sequencemotif.py,v 1.2 2004/05/22 21:50:15 mliang Exp $
# Copyright (c) 2003 Mike Liang. All rights reserved.

"""
Represents a Sequence pattern and supports scanning of protein structure for locacation of pattern
"""

